@echo off
rem Opens all three Sotej templates in Chrome
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "file:///C:/Users/Huzaifa/Desktop/sotej/sotej-travel/index.html"
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "file:///C:/Users/Huzaifa/Desktop/sotej/sotej-fragrances/index.html"
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "file:///C:/Users/Huzaifa/Desktop/sotej/sotej-properties/index.html"
