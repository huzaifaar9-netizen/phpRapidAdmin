# Sotej Properties — one-page template

Real estate & investment site for **Sotej Properties**. Self-contained: no build step, no dependencies, no CMS required.

## Open it
Double-click `index.html`, or serve the folder:
```powershell
cd C:\Users\Huzaifa\Desktop\sotej\sotej-properties
python -m http.server 8085   # then visit http://localhost:8085
```

## Edit everything (two ways)

### A. Visual "Edit content" mode (easiest)
1. Open the page with `?edit=1`, e.g. `index.html?edit=1` — or press **Ctrl + Shift + E**.
2. Click any outlined text to edit it inline (auto-saves in this browser).
3. Click any image to replace it (prompted for URL + alt text).
4. Bottom toolbar: change **brand colours** (terracotta / slate / brass / page background), **Export edits (.json)**, **Reset**, or **Done** to exit.
5. Keep edits in-browser, export them as a backup, or bake them into `index.html` for all visitors.

Normal visitors never see any edit controls.

### B. Edit the files directly
- Copy lives in `index.html` between `data-edit="…"` markers — search `data-edit` to find every string.
- Swap any `<img src>` (and its `alt`). Prices and sizes are plain text.
- Contact: edit the `mailto:`/`tel:` links, visible text, and the form's `data-email` attribute.
- Theme: CSS custom properties at the top of `css/styles.css` (`--brand`, `--accent`, `--brass`, `--bg`, …).

## Features
- Sticky header, mobile menu, skip link, visible focus, semantic landmarks
- Warm stone / terracotta / deep slate & brass palette with Marcellus (architectural serif) and a subtle blueprint-grid hero
- Hero, 6 property services, deep-slate "Why us" band, 4 featured listings with sample PKR pricing, testimonial carousel, accessible contact form (validation + honeypot + status message)
- Form opens the visitor's email client pre-filled — no backend required
- `prefers-reduced-motion` supported; carousel works with ←/→ keys and buttons
- All listings, prices and testimonials are sample content — replace with your real portfolio, rates and stories before publishing
