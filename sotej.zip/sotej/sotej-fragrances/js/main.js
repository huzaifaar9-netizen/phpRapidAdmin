/* ============================================================
   Sotej — shared site engine
   - Sticky header + mobile navigation
   - "Edit content" mode (visit ?edit=1 or press Ctrl+Shift+E)
     · click any outlined text to edit it inline
     · click any image to replace its URL and alt text
     · use the toolbar to tweak brand colours, export or reset
     · edits are stored in this browser (localStorage) and are
       NEVER visible to normal visitors unless you export them
       and bake them into the HTML.
   - Testimonial carousel (buttons + arrow keys, reduced-motion aware)
   - Accessible contact form (validation + mailto fallback + status)
   ============================================================ */
(function () {
  'use strict';

  var SITE = document.body.getAttribute('data-site') || 'sotej';
  var STORAGE_KEY = 'sotej:' + SITE + ':edits';
  var root = document.documentElement;

  /* ---------- stored edits ---------- */
  function loadEdits() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; }
    catch (err) { return {}; }
  }
  function saveEdits(data) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch (err) { /* storage full/blocked */ }
  }
  var edits = loadEdits();

  function applyEdits(e) {
    if (!e) return;
    document.querySelectorAll('[data-edit]').forEach(function (el) {
      var k = el.getAttribute('data-edit');
      if (Object.prototype.hasOwnProperty.call(e, k)) el.innerHTML = e[k];
    });
    var imgs = e.__images || {};
    document.querySelectorAll('[data-edit-img]').forEach(function (img) {
      var k = img.getAttribute('data-edit-img');
      if (imgs[k]) img.src = imgs[k];
    });
    var alts = e.__alts || {};
    document.querySelectorAll('[data-edit-alt]').forEach(function (img) {
      var k = img.getAttribute('data-edit-alt');
      if (alts[k]) img.alt = alts[k];
    });
    var colors = e.__colors || {};
    Object.keys(colors).forEach(function (v) { root.style.setProperty(v, colors[v]); });
  }
  applyEdits(edits);

  /* ---------- edit mode ---------- */
  var editing = false;
  var toolbar = null;
  var saveTimer = null;

  function editRequested() {
    return /(?:^|[?&])edit=1(?:&|$)/.test(window.location.search) || window.location.hash === '#edit';
  }

  function setEditable(on) {
    document.querySelectorAll('[data-edit]').forEach(function (el) {
      if (on) {
        el.setAttribute('contenteditable', 'true');
        el.setAttribute('spellcheck', 'true');
        el.setAttribute('data-edit-label', el.getAttribute('data-edit'));
      } else {
        el.removeAttribute('contenteditable');
      }
    });
    root.classList.toggle('is-editing', on);
  }

  function queueSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () { saveEdits(edits); }, 250);
  }

  function exportEdits() {
    var blob = new Blob([JSON.stringify(edits, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = SITE + '-content-edits.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  function resetEdits() {
    var ok = window.confirm('Reset ALL edits for this site to the original content? This cannot be undone.');
    if (!ok) return;
    try { localStorage.removeItem(STORAGE_KEY); } catch (err) { /* ignore */ }
    window.location.href = window.location.pathname;
  }

  function buildToolbar() {
    if (toolbar) return toolbar;
    toolbar = document.createElement('div');
    toolbar.className = 'edit-toolbar';
    toolbar.setAttribute('role', 'region');
    toolbar.setAttribute('aria-label', 'Content edit toolbar');

    var title = document.createElement('strong');
    title.className = 'edit-toolbar__title';
    title.textContent = 'Edit mode';
    toolbar.appendChild(title);

    var hint = document.createElement('span');
    hint.className = 'edit-toolbar__hint';
    hint.textContent = 'Click outlined text to edit · click an image to replace it · changes save in this browser';
    toolbar.appendChild(hint);

    /* colour pickers from <body data-colors="--brand:Brand,..."> */
    var colorsAttr = document.body.getAttribute('data-colors') || '';
    var pairs = colorsAttr.split(',').map(function (s) { return s.trim(); }).filter(Boolean);
    if (pairs.length) {
      var colorWrap = document.createElement('div');
      colorWrap.className = 'edit-toolbar__colors';
      pairs.forEach(function (pair) {
        var parts = pair.split(':');
        var varName = parts[0].trim();
        var label = (parts[1] || parts[0]).trim();
        var current = getComputedStyle(root).getPropertyValue(varName).trim() || '#000000';
        /* colour inputs need hex — convert rgb() if needed */
        if (current.charAt(0) !== '#') {
          var m = current.match(/rgba?\((\d+)[,\s]+(\d+)[,\s]+(\d+)/i);
          if (m) {
            current = '#' + [m[1], m[2], m[3]].map(function (n) {
              return ('0' + parseInt(n, 10).toString(16)).slice(-2);
            }).join('');
          } else { current = '#000000'; }
        }
        var id = 'color-' + varName.replace(/[^a-z0-9]/gi, '');
        var lab = document.createElement('label');
        lab.className = 'edit-toolbar__color';
        lab.setAttribute('for', id);
        lab.textContent = label;
        var input = document.createElement('input');
        input.type = 'color';
        input.id = id;
        input.value = current.length === 4
          ? '#' + current[1] + current[1] + current[2] + current[2] + current[3] + current[3]
          : current.slice(0, 7);
        input.addEventListener('input', function () {
          root.style.setProperty(varName, input.value);
          edits.__colors = edits.__colors || {};
          edits.__colors[varName] = input.value;
          queueSave();
        });
        lab.appendChild(input);
        colorWrap.appendChild(lab);
      });
      toolbar.appendChild(colorWrap);
    }

    var actions = document.createElement('div');
    actions.className = 'edit-toolbar__actions';

    var exportBtn = document.createElement('button');
    exportBtn.type = 'button';
    exportBtn.className = 'edit-btn edit-btn--ghost';
    exportBtn.textContent = 'Export edits (.json)';
    exportBtn.addEventListener('click', exportEdits);
    actions.appendChild(exportBtn);

    var resetBtn = document.createElement('button');
    resetBtn.type = 'button';
    resetBtn.className = 'edit-btn edit-btn--ghost';
    resetBtn.textContent = 'Reset';
    resetBtn.addEventListener('click', resetEdits);
    actions.appendChild(resetBtn);

    var doneBtn = document.createElement('button');
    doneBtn.type = 'button';
    doneBtn.className = 'edit-btn edit-btn--solid';
    doneBtn.textContent = 'Done';
    doneBtn.addEventListener('click', function () { toggleEdit(false); });
    actions.appendChild(doneBtn);

    toolbar.appendChild(actions);
    document.body.appendChild(toolbar);
    return toolbar;
  }

  function toggleEdit(force) {
    var next = typeof force === 'boolean' ? force : !editing;
    editing = next;
    if (editing) {
      buildToolbar();
      toolbar.hidden = false;
      setEditable(true);
    } else {
      if (toolbar) toolbar.hidden = true;
      setEditable(false);
      saveEdits(edits);
      /* leave ?edit in the URL but remember preference for this tab */
      try { sessionStorage.setItem('sotej:' + SITE + ':edit-dismissed', '1'); } catch (err) { /* ignore */ }
    }
  }

  /* live-save text edits */
  document.addEventListener('input', function (event) {
    if (!editing) return;
    var el = event.target.closest ? event.target.closest('[data-edit]') : null;
    if (!el) return;
    edits[el.getAttribute('data-edit')] = el.innerHTML;
    queueSave();
  });

  /* replace images (and their alt text) on click while editing */
  document.addEventListener('click', function (event) {
    if (!editing) return;
    var img = event.target.closest ? event.target.closest('[data-edit-img]') : null;
    if (!img) return;
    event.preventDefault();
    event.stopPropagation();
    var key = img.getAttribute('data-edit-img');
    var url = window.prompt('Image URL', img.currentSrc || img.src);
    if (url == null) return;
    url = url.trim();
    var alt = window.prompt('Describe the image (alt text)', img.alt || '');
    if (url) {
      img.src = url;
      edits.__images = edits.__images || {};
      edits.__images[key] = url;
    }
    if (alt != null) {
      img.alt = alt;
      edits.__alts = edits.__alts || {};
      edits.__alts[key] = alt;
    }
    saveEdits(edits);
  }, true);

  /* Ctrl+Shift+E toggles edit mode */
  document.addEventListener('keydown', function (event) {
    if (event.ctrlKey && event.shiftKey && (event.key === 'E' || event.key === 'e')) {
      event.preventDefault();
      var dismissed = false;
      try { dismissed = sessionStorage.getItem('sotej:' + SITE + ':edit-dismissed') === '1'; } catch (err) { /* ignore */ }
      if (!editing && dismissed && !editRequested()) {
        /* re-enable even if previously dismissed via Done */
        try { sessionStorage.removeItem('sotej:' + SITE + ':edit-dismissed'); } catch (err) { /* ignore */ }
      }
      toggleEdit();
    }
  });

  if (editRequested()) {
    var dismissedInitially = false;
    try { dismissedInitially = sessionStorage.getItem('sotej:' + SITE + ':edit-dismissed') === '1'; } catch (err) { /* ignore */ }
    if (!dismissedInitially) toggleEdit(true);
  }

  /* ---------- sticky header shadow ---------- */
  var header = document.querySelector('.site-header');
  function onScroll() {
    if (!header) return;
    header.classList.toggle('is-scrolled', window.scrollY > 24);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- mobile navigation ---------- */
  var navToggle = document.querySelector('.nav-toggle');
  var navMenu = document.getElementById('nav-menu');
  if (navToggle && navMenu) {
    var setMenu = function (open) {
      navToggle.setAttribute('aria-expanded', String(open));
      navMenu.classList.toggle('is-open', open);
      document.body.classList.toggle('nav-open', open);
    };
    navToggle.addEventListener('click', function () {
      setMenu(navToggle.getAttribute('aria-expanded') !== 'true');
    });
    navMenu.addEventListener('click', function (event) {
      if (event.target.closest('a')) setMenu(false);
    });
    document.addEventListener('click', function (event) {
      if (!navMenu.classList.contains('is-open')) return;
      if (event.target.closest('.site-header')) return;
      setMenu(false);
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') setMenu(false);
    });
  }

  /* ---------- testimonial carousels ---------- */
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  document.querySelectorAll('[data-carousel]').forEach(function (carousel) {
    var slides = Array.prototype.slice.call(carousel.querySelectorAll('.testimonial'));
    var prev = carousel.querySelector('[data-carousel-prev]');
    var next = carousel.querySelector('[data-carousel-next]');
    var dotsWrap = carousel.querySelector('[data-carousel-dots]');
    if (!slides.length) return;
    var index = 0;

    var dots = slides.map(function (_, i) {
      var dot = document.createElement('button');
      dot.type = 'button';
      dot.className = 'carousel-dot';
      dot.setAttribute('aria-label', 'Show testimonial ' + (i + 1));
      dot.addEventListener('click', function () { go(i); });
      if (dotsWrap) dotsWrap.appendChild(dot);
      return dot;
    });

    function go(i) {
      index = (i + slides.length) % slides.length;
      slides.forEach(function (slide, s) {
        var active = s === index;
        slide.classList.toggle('is-active', active);
        slide.setAttribute('aria-hidden', String(!active));
      });
      dots.forEach(function (dot, d) {
        dot.classList.toggle('is-active', d === index);
        dot.setAttribute('aria-current', d === index ? 'true' : 'false');
      });
    }
    if (prev) prev.addEventListener('click', function () { go(index - 1); });
    if (next) next.addEventListener('click', function () { go(index + 1); });
    carousel.addEventListener('keydown', function (event) {
      if (event.key === 'ArrowLeft') { event.preventDefault(); go(index - 1); }
      if (event.key === 'ArrowRight') { event.preventDefault(); go(index + 1); }
    });
    go(0);

    /* gentle auto-advance only with motion allowed and tab visible */
    if (!reduceMotion.matches) {
      var timer = window.setInterval(function () {
        if (document.hidden || editing) return;
        go(index + 1);
      }, 7000);
      carousel.addEventListener('mouseenter', function () { window.clearInterval(timer); });
    }
  });

  /* ---------- contact form ---------- */
  var form = document.getElementById('contact-form');
  if (form) {
    var status = form.querySelector('.form-status');
    var honeypot = form.querySelector('input[name="company_website"]');
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      if (honeypot && honeypot.value) return; /* silently drop bots */
      if (!form.checkValidity()) { form.reportValidity(); return; }

      var data = new FormData(form);
      var to = form.getAttribute('data-email') || 'hello@example.com';
      var lines = [];
      data.forEach(function (value, key) {
        if (key === 'company_website') return;
        lines.push(key.replace(/_/g, ' ') + ': ' + value);
      });
      var subject = 'Website enquiry — ' + (data.get('name') || 'New lead');
      var mailto = 'mailto:' + to +
        '?subject=' + encodeURIComponent(subject) +
        '&body=' + encodeURIComponent(lines.join('\n'));
      window.location.href = mailto;

      if (status) {
        status.textContent = 'Thank you, ' + (data.get('name') || 'there') +
          '! Your email app should open with your message pre-filled. If it did not, email us directly at ' + to + '.';
        status.classList.add('is-visible');
        status.setAttribute('tabindex', '-1');
        status.focus({ preventScroll: false });
      }
      form.reset();
    });
  }

  /* ---------- footer year + back to top ---------- */
  document.querySelectorAll('[data-current-year]').forEach(function (el) {
    el.textContent = String(new Date().getFullYear());
  });
  var toTop = document.querySelector('.to-top');
  if (toTop) {
    var toggleTop = function () { toTop.classList.toggle('is-visible', window.scrollY > 480); };
    window.addEventListener('scroll', toggleTop, { passive: true });
    toggleTop();
    toTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: reduceMotion.matches ? 'auto' : 'smooth' });
    });
  }
})();
