@echo off
rem Opens the Sotej Travel template in Google Chrome (no server needed)
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "file:///C:/Users/Huzaifa/Desktop/sotej/sotej-travel/index.html"
