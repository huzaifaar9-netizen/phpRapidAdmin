# Sotej — three brand website templates

Three separate, self-contained one-page templates sharing the Sotej identity
(blue→green mark, tagline **"Fresh Ideas, Brighter Tomorrow."**):

| Folder | Brand | Personality | Open |
|---|---|---|---|
| `sotej-travel/` | Sotej Travel — travel & tours | Warm cream, deep pine green, golden-hour accent, Playfair Display | `sotej-travel/index.html` |
| `sotej-fragrances/` | Sotej Fragrances — perfume & lifestyle | Porcelain & aubergine, rosewood & gold, Cormorant Garamond | `sotej-fragrances/index.html` |
| `sotej-properties/` | Sotej Properties — real estate & investment | Warm stone, terracotta, deep slate & brass, Marcellus (blueprint-grid hero) | `sotej-properties/index.html` |

## Sending these to someone (sharing)
The `shareable\` folder holds the same three sites as **single self-contained
`index.html` files** (all CSS and JS inlined, no other files needed):

- `shareable\sotej-travel\index.html`
- `shareable\sotej-fragrances\index.html`
- `shareable\sotej-properties\index.html`
- `shareable\READ ME FIRST.txt` (how the recipient opens/edits them)

`Sotej-Websites.zip` contains exactly these four items, ready to email or
hand over on a USB drive. Each file opens in any browser by double-clicking —
no install, no server, no build. Only requirement: an internet connection for
the photos (hot-linked from Unsplash) and web fonts; everything else works
offline. To make the images work offline too, swap the `<img src>` URLs for
local files inside the HTML.

## How to preview
Double-click any `index.html`, or serve a folder (recommended so images and JS behave exactly like production):

```powershell
cd C:\Users\Huzaifa\Desktop\sotej\sotej-travel   # or sotej-fragrances / sotej-properties
python -m http.server 8080
```

Use a different port per folder (8080–8082) if you want all three open at once.
The `Open *.cmd` launchers in this folder open each template directly in Chrome.

## How editing works (no rebuilding)
Every page ships with a hidden, clearly labelled **Edit content** mode:

1. Open the page with `?edit=1` appended — e.g. `index.html?edit=1` — or press **Ctrl + Shift + E** while on the page.
2. Text with a dashed outline is click-to-edit (saves automatically in your browser).
3. Click any image to swap its URL and alt text.
4. The bottom toolbar lets you change brand colours live, export your edits as a `.json` backup, reset to defaults, or exit edit mode.

Visitors never see the outlines or toolbar. To change content permanently for
all visitors, either edit the HTML/CSS files directly (every string lives in
`index.html` next to a `data-edit="…"` marker; colours live in the `:root` block
at the top of each `css/styles.css`), or bake exported edits into the HTML.

See each folder's `README.md` for full details.

## Shared features (all three)
- Semantic HTML5 landmarks, skip link, visible keyboard focus, accessible form labels/errors
- Responsive: desktop → tablet → phone (hamburger nav under 900px)
- Sticky blurred header, smooth scrolling, back-to-top button
- Testimonial carousel with arrow-key support and `aria-live` announcements
- Working contact form: client-side validation, honeypot spam trap, opens the
  visitor's email app pre-filled (no backend needed) and shows a `role="status"` confirmation
- `prefers-reduced-motion` respected — animations and smooth scrolling are disabled
- All navigation links, buttons and CTAs scroll to real sections; social icons link out to the platforms (replace with your profiles); email/phone use `mailto:`/`tel:`
- Placeholder imagery from Unsplash (swap freely via edit mode or `<img>` tags); no text baked into images; no third-party logos copied

## Before you publish
Replace the sample content — stats, client names, testimonials, prices and contact
details are fictional placeholders — and point the social icons and form
`data-email` attributes at your real accounts/inbox. For a real deployment with
a backend form handler, replace the form's `submit` handler in `js/main.js` (or
point `action` at your form service) — each folder documents its own edit keys.
