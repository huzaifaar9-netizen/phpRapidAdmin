@echo off
rem Opens the Sotej Travel template in Chrome in Edit content mode (Ctrl+Shift+E also works)
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "file:///C:/Users/Huzaifa/Desktop/sotej/sotej-travel/index.html?edit=1"

