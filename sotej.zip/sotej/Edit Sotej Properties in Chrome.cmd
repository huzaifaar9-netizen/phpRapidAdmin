@echo off
rem Opens the Sotej Properties template in Chrome in Edit content mode (Ctrl+Shift+E also works)
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "file:///C:/Users/Huzaifa/Desktop/sotej/sotej-properties/index.html?edit=1"
