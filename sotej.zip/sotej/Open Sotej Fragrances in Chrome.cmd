@echo off
rem Opens the Sotej Fragrances template in Google Chrome (no server needed)
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "file:///C:/Users/Huzaifa/Desktop/sotej/sotej-fragrances/index.html"
