# Sotej Fragrances — one-page template

Perfume & lifestyle atelier site for **Sotej Fragrances**. Self-contained: no build step, no dependencies, no CMS required.

## Open it
Double-click `index.html`, or serve the folder:
```powershell
cd C:\Users\Huzaifa\Desktop\sotej\sotej-fragrances
python -m http.server 8084   # then visit http://localhost:8084
```

## Edit everything (two ways)

### A. Visual "Edit content" mode (easiest)
1. Open the page with `?edit=1`, e.g. `index.html?edit=1` — or press **Ctrl + Shift + E**.
2. Click any outlined text to edit it inline (auto-saves in this browser).
3. Click any image to replace it (prompted for URL + alt text).
4. Bottom toolbar: change **brand colours** (aubergine / rosewood / gold / page background), **Export edits (.json)**, **Reset**, or **Done** to exit.
5. Keep edits in-browser, export them as a backup, or bake them into `index.html` for all visitors.

Normal visitors never see any edit controls.

### B. Edit the files directly
- Copy lives in `index.html` between `data-edit="…"` markers — search `data-edit` to find every string.
- Swap any `<img src>` (and its `alt`). Prices and bottle sizes are plain text.
- Contact: edit the `mailto:`/`tel:` links, visible text, and the form's `data-email` attribute.
- Theme: CSS custom properties at the top of `css/styles.css` (`--brand`, `--accent`, `--gold`, `--bg`, …).

## Features
- Sticky header, mobile menu, skip link, visible focus, semantic landmarks
- Porcelain / deep aubergine / rosewood & gold palette with Cormorant Garamond
- Hero, 6 atelier services, plum "Why us" band, 4-scent Signature Edit with sample pricing, testimonial carousel, accessible contact form (validation + honeypot + status message)
- Form opens the visitor's email client pre-filled — no backend required
- `prefers-reduced-motion` supported; carousel works with ←/→ keys and buttons
- All scents, prices and testimonials are sample content — replace with your real collection, rates and stories before publishing
